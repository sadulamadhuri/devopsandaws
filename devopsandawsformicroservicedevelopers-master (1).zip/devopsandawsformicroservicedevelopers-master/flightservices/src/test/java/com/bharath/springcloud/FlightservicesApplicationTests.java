package com.bharath.springcloud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FlightservicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
